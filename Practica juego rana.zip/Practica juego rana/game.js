// define variables
var game;
var player;
var platforms;
var badges;
var items;
var cursors;
var jumpButton;
var text;
var text2;
var winningMessage;
var losingMessage;
var won = false;
var lose = false;
var currentScore = 10;
var currentLives = 2;
var winningScore = 100;

// add collectable items to the game
function addItems() { //primer numero: horizontal segundo: vertical

    //Leemos de arriba abajo y por agrupaciones
    items = game.add.physicsGroup();
    createItem(350, 110, 'poison'); //1º
    createItem(350, 500, 'poison'); //2º

    createItem(600, 91, 'coin'); // 1º
    createItem(180, 200, 'coin'); //2º
    createItem(660, 200, 'coin'); //3º
    createItem(60, 240, 'coin'); //4º
    createItem(500, 250, 'coin'); //5º
    createItem(320, 350, 'coin'); //6º
    createItem(200, 500, 'coin'); // 7º
    createItem(550, 500, 'coin'); // 8º

    createItem(125, 50, 'star'); //ESTRELLA

}

// add platforms to the game
function addPlatforms() {
    //Leemos de arriba abajo y por agrupaciones

    platforms = game.add.physicsGroup();
    platforms.create(100, 100, 'platform2'); // 1º
    platforms.create(550, 150, 'platform2'); //2º
    platforms.create(400, 300, 'platform2'); //3º
    platforms.create(250, 400, 'platform2'); //4º

    platforms.create(250, 150, 'platform'); // 1º
    platforms.create(100, 250, 'platform'); //2º
    platforms.create(650, 250, 'platform'); //3º
    platforms.create(50, 290, 'platform'); //4º
    platforms.create(100, 550, 'platform'); //5º
    platforms.create(450, 550, 'platform'); //6º

    platforms.setAll('body.immovable', true);
}


// create a single animated item and add to screen
function createItem(left, top, image) {
    var item = items.create(left, top, image);
    item.animations.add('spin');
    item.animations.play('spin', 20, true);
}

// create the winning badge and add to screen
function createBadge() {
    badges = game.add.physicsGroup();
    var badge = badges.create(700, 400, 'badge');
    badge.animations.add('spin');
    badge.animations.play('spin', 10, true);
}

// when the player collects an item on the screen
function itemHandler(player, item) {
    item.kill();
    switch (item.key) {
        case 'coin':
            currentScore = currentScore + 10;
            break;

        case 'poison':
            currentScore = currentScore - 50;
            if (currentScore <= 0) {
                currentLives = currentLives - 1;
            }
            break;

        case 'star':
            currentScore = currentScore + 50;
            break;
    }

    if (currentScore >= winningScore) {
        createBadge();

    }
}

// when the player collects the badge at the end of the game
function badgeHandler(player, badge) {
    badge.kill();
    won = true;
}

// setup game when the web page loads
window.onload = function() {
    game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update, render: render });

    // before the game begins
    function preload() {

        game.stage.backgroundColor = '#571845';


        //Load images
        game.load.image('platform', 'platform_1.png');
        game.load.image('platform2', 'platform_2.png');

        //Load spritesheets
        game.load.spritesheet('player', 'rana.png', 32, 32);
        game.load.spritesheet('coin', 'coin.png', 36, 44);
        game.load.spritesheet('badge', 'badge.png', 42, 54);
        game.load.spritesheet('poison', 'poison.png', 32, 0);
        game.load.spritesheet('star', 'star.png', 32, 30);


    }

    // initial game set up
    function create() {
        player = game.add.sprite(50, 600, 'player');
        player.animations.add('walk');
        player.anchor.setTo(0.5, 1);
        game.physics.arcade.enable(player);
        player.body.collideWorldBounds = true;
        player.body.gravity.y = 300; //GRAVEDAD

        addItems();
        addPlatforms();

        cursors = game.input.keyboard.createCursorKeys();
        jumpButton = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        text = game.add.text(16, 16, "PUNTUASION: " + currentScore, { font: "bold 24px Arial", fill: "Gold" });
        text2 = game.add.text(650, 16, "VIDAS: " + currentLives, { font: "bold 24px Arial", fill: "Gold" });
        winningMessage = game.add.text(game.world.centerX, 275, "", { font: "bold 48px Arial", fill: "white" });
        winningMessage.anchor.setTo(0.5, 1);
        losingMessage = game.add.text(game.world.centerX, 275, "", { font: "bold 48px Arial", fill: "Black" });
        losingMessage.anchor.setTo(0.5, 1);
    }

    // while the game is running
    function update() {

        text.text = "PUNTUASIÓN: " + currentScore;
        text2.text = "VIDAS: " + currentLives;
        game.physics.arcade.collide(player, platforms);
        game.physics.arcade.overlap(player, items, itemHandler);
        game.physics.arcade.overlap(player, badges, badgeHandler);
        player.body.velocity.x = 1;

        // is the left cursor key presssed?
        if (cursors.left.isDown) {
            player.animations.play('walk', 100, true);
            player.body.velocity.x = -300; //velocidad
            player.scale.x = -1;
        }
        // is the right cursor key pressed?
        else if (cursors.right.isDown) {
            player.animations.play('walk', 100, true);
            player.body.velocity.x = 300; //velocidad
            player.scale.x = 1;
        }
        // player doesn't move
        else {
            player.animations.stop();
        }

        if (jumpButton.isDown && (player.body.onFloor() || player.body.touching.down)) {
            player.body.velocity.y = -300;
            player.body.velocity.y = -300;
        }
        // when the player winw the game
        if (won) {
            winningMessage.text = "YOU WIN !!!";
        } else if (currentLives == 0) {
            losingMessage.text = "N00B!!!";

        }
    }

    function render() {

    }

};